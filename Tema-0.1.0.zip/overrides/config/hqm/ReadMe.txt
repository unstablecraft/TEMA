How to copy quests to a server:
In HQM for 1.11.2 the file copying to a server works again. Copy the hqm/quests to the server side config hqm/quests.
There is a config option to automatically sync the server quests to the client.
